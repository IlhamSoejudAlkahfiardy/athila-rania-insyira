<center>
	
	  <form name="form1" method="post" action="laporan.php" target="_blank">
   
    <p class="style1 style3"><strong>CETAK LAPORAN DATA TRANSAKSI </strong></p>
    <p class="style4"><span class="style5 style20">TOKO AQILLAH MART </span></p>
    <div style="width: 100px;">
    	<input class="form-control" width="30px" name="id_transaksi" type="text" id="nim">
    	
    </div> <br>
    <div>
    	<input class="btn btn-info" name="cetak" type="submit" id="cetak" value="CETAK">
    	
    </div>
  </form>
</center>